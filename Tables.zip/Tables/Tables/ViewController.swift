//
//  ViewController.swift
//  Tables
//
//  Created by Гость on 14.04.2022.
//

import UIKit

@IBOutler weak var cellLabel

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

